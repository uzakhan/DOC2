select * from tahakkuk_donem where hizmet_turu=21

hizmet_turu

select * from dba_directories


tms.pck_dosya.TahakkukDosyaJob(true);



select * from dosya where yil_ay='201102' and dosya_adi like 'TTVPN%'

select * from tms.v_dosya where dis_sistem_tipi ='TTVPN'

exec tms.pck_dosya.dosyayaz(171624,true)




select * from tms.v_job_history where aciklama like '%TTVPN%'