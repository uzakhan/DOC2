

select * from ebasaran.S_ASSET_BACKUP where serial_num in (
select a.SERIAL_NUM from S_ASSET_BACKUP a ,siebel.s_asset b where a.serial_num=b.serial_num 
having count(*) > 1
group by a.SERIAL_NUM)
order by serial_num


delete from ebasaran.S_ASSET_BACKUP c where c.serial_num in (
select serial_num from ebasaran.S_ASSET_BACKUP where serial_num in (
select a.SERIAL_NUM from S_ASSET_BACKUP a
having count(*) > 1
group by a.SERIAL_NUM)) and X_TT_CH_SCORE is null;




select a.SERIAL_NUM,count(*)from S_ASSET_BACKUP a ,siebel.s_asset b where a.serial_num=b.serial_num 
having count(*) > 1
group by a.SERIAL_NUM

--49984

2124910112
2242114613

DELETE FROM EBASARAN.S_ASSET_BACKUP A WHERE    ROWID > (
SELECT min(rowid) FROM EBASARAN.S_ASSET_BACKUP  B
WHERE A.SERIAL_NUM = B.SERIAL_NUM);


DELETE FROM EBASARAN.S_ORG_EXT_BACKUP A WHERE ROWID > (
SELECT min(rowid) FROM EBASARAN.S_ORG_EXT_BACKUP B
WHERE A.NAME = B.NAME);



select count(distinct name) from S_ORG_EXT_BACKUP