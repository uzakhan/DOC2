
--shrink temp tablespace. 11g ile gelen br �zellik. sadece temp tablespace'lerde yap�labilir.
--online operasyon oldu�undan �al��an session ve tarsnsactionlar etkilenmez.
--lmtemp1 tablespaceini 20M'ye shrink etmeye �al���r.
ALTER TABLESPACE lmtemp1 SHRINK SPACE KEEP 20M;
--lmtemp1 tablespaceinin yap�labilecek b�t�n shrinki yapar.
 ALTER TABLESPACE lmtemp1 SHRINK SPACE 
 
 --datafile baz�nda shrink yapmak i�in (sadece temp datafile'da ge�erlidir. onlne yap�labilir)
 ALTER TABLESPACE lmtemp2 SHRINK TEMPFILE '/u02/oracle/data/lmtemp02.dbf';
 
*******************************************************************
* RESIZE TABLESPACE
*******************************************************************
--resize tablespace sadece bigfile tablespacelerde olur
ALTER TABLESPACE bigtbs RESIZE 80G;
--bigfile tablespacelerde datafile eklemeden autoextend de�eri verilebilir.
ALTER TABLESPACE bigtbs AUTOEXTEND ON NEXT 20G;