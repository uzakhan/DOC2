select 'ADD TRANDATA YAPA_TAHAKKUK.'||table_name from
(select table_name from  DBA_tables where owner='YAPA_TAHAKKUK'
minus
select table_name from  DBA_LOG_GROUPS where owner='YAPA_TAHAKKUK')