select
   fs.tablespace_name          "Tablespace",
     b.status                  "Status",
    b.contents                 "Type",
    b.extent_management        "Extent Mgmt",
   df.totalspace               bytes,
    df.totalspace              bytes_max,
   fs.freespace                bytes_free,
   100-round(100 * (fs.freespace / df.totalspace)) "Pct. Free"
from
   (select
      tablespace_name,
      round(sum(bytes)) TotalSpace
   from
      dba_data_files
   group by
      tablespace_name
   ) df,
   (select
      tablespace_name,
      round(sum(bytes)) FreeSpace
   from
      dba_free_space
   group by
      tablespace_name
   ) fs,
    sys.dba_tablespaces b
where
   df.tablespace_name = fs.tablespace_name
   and df.tablespace_name=b.tablespace_name
   and b.tablespace_name not in ('TEMP','TEMP_TEMP','UNDOTBS2','UNDOTBS1')
   and 100-round(100 * (fs.freespace / df.totalspace)) >90
   order by 8 desc