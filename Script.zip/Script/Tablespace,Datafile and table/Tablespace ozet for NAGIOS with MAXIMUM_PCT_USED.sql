select   b.tablespace_name "Tablespace",
           c.status "Status",
           c.contents "Type",
           c.extent_management "Extent Mgmt",
           a.bytes_alloc bytes,
           a.maxbytes bytes_max,
           b.freespace bytes_free,
       round((round((a.bytes_alloc - nvl(b.FreeSpace, 0)) / 1024 / 1024)*100)/round(maxbytes/1048576)) "Pct. Free"
from  ( select  f.tablespace_name,
               round(sum(f.bytes)) bytes_alloc,
               sum(decode(f.autoextensible, 'YES',f.maxbytes,'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select  f.tablespace_name,
               round(sum(f.bytes))  FreeSpace
        from dba_free_space f
        group by tablespace_name) b,
         sys.dba_tablespaces c
where a.tablespace_name = b.tablespace_name (+)
and a.tablespace_name=c.tablespace_name
 AND c.tablespace_name NOT IN
                    ('TEMP', 'TEMP_TEMP', 'UNDOTBS2', 'UNDOTBS1')
                    and round((round((a.bytes_alloc - nvl(b.FreeSpace, 0)) / 1024 / 1024)*100)/round(maxbytes/1048576)) > 90
ORDER BY 8 desc
