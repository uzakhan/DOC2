
select distinct sp.sql_id, sp.object#, (select sql_text from v$sqlarea where sql_id=sp.sql_id) sql_text from v$sql_plan sp where sp.object# in ( select /*+ NO_UNNEST */ object_id from dba_objects 
                     where (object_type, object_name, owner) in
                               (select /*+ NO_UNNEST */ 'INDEX', index_name, owner 
                                from dba_indexes 
                                where table_name='ISEMRI' 
                                  and table_owner='TMS'));
