


-- DOLULUK  ORANI %90 I GECEN  TABLE SPACELER

Select TT.*,(TT.Used*100-TT.TOTAL*75)/75 EKLENECEK from (SELECT Total.name "Tablespace Name",
       total_space TOTAL,
       nvl(total_space-Free_space, 0) Used, 
       nvl(Free_space, 0) Free,       
       round((nvl(total_space-Free_space, 0)*100)/total_space,1) USED_PERCENT
       
FROM
  (select tablespace_name, sum(bytes/1024/1024) Free_Space
     from sys.dba_free_space
    group by tablespace_name
  ) Free,
  (select b.name,  sum(bytes/1024/1024) TOTAL_SPACE
     from sys.v_$datafile a, sys.v_$tablespace B
    where a.ts# = b.ts#
    group by b.name
  ) Total
WHERE Free.Tablespace_name(+) = Total.name
ORDER BY Total.name ) TT

where TT.USED_PERCENT >79
ORDER BY TT.USED_PERCENT


