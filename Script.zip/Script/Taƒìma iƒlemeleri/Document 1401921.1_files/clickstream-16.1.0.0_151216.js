/* 
 * script related to omniture log
 */

//var s is defined in s_code_xxxx.js with given account.
//it's mandatory to include s_code_xxxx.js before this script
var OMNITURE_MAX_PROP_NO = 9;

function logOmnitureTrackLink(linkName, propArray) {
    var propNames = '';
    var propIndex;
    var propCount = propArray.length;

    if (propCount > 0) {
        for (propIndex = 1;propIndex <= propCount;propIndex++) {
            if (propIndex > 0) {
                propNames += ',';
            }
            propNames += ('prop' + propIndex);
        }

        s.linkTrackVars = propNames;
    }

    for (propIndex = 1;propIndex <= propCount;propIndex++) {
        s['prop' + propIndex] = propArray[propIndex - 1];
    }

    s.tl(this, 'o', linkName);
}

function logOmnitureTrackClickEvent(pageName, actionCategory, actionType, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15) {
    if (pageName && actionCategory && actionType) {

        var s = s_gi(s_account);

        s.pageName = pageName;
        //s.prop1 = p1;        
        if (actionCategory) {
            s.prop1 = actionCategory;
        }
        else {
            s.prop1 = "";
        }
        if (actionType) {
            s.prop2 = actionType;
        }
        else {
            s.prop2 = "";
        }
        
        // extra attributes
        if (p1) {
            s.prop3 = p1;
        }
        else {
            s.prop3 = "";
        }
        if (p2) {
            s.prop4 = p2;
        }
        else {
            s.prop4 = "";
        }
        if (p3) {
            s.prop5 = p3;
        }
        else {
            s.prop5 = "";
        }
        if (p4) {
            s.prop6 = p4;
        }
        else {
            s.prop6 = "";
        }
        if (p5) {
            s.prop7 = p5;
        }
        else {
            s.prop7 = "";
        }
        if (p6) {
            s.prop8 = p6;
        }
        else {
            s.prop8 = "";
        }
        if (p7) {
            s.prop9 = p7;
        }
        else {
            s.prop9 = "";
        }
        if (p8) {
            s.prop10 = p8;
        }
        else {
            s.prop10 = "";
        }
//        if (p11) {
//            s.prop11 = p11;
//        }
//        else {
//            s.prop11 = "";
//        }
//        if (p12) {
//            s.prop12 = p12;
//        }
//        else {
//            s.prop12 = "";
//        }
//        if (p13) {
//            s.prop13 = p13;
//        }
//        else {
//            s.prop13 = "";
//        }
//        if (p14) {
//            s.prop14 = p14;
//        }
//        else {
//            s.prop14 = "";
//        }
//        if (p15) {
//            s.prop15 = p15;
//        }
//        else {
//            s.prop15 = "";
//        }
        s.tl();
    }
}

function logOmnitureTrackView(pageName, propArray) {
    if (pageName && pageName != "") {
        s.pageName = pageName;
    }
    else {
        s.pageName = windows.pageName;
    }

    if (pageName && pageName != "") {
        if (propArray.length > 0) {
            for (pIdx = 0;pIdx < propArray.length;pIdx++) {
                switch (pIdx) {
                    case 0:
                        s.prop1 = propArray[pIdx];
                        break;
                    case 1:
                        s.prop2 = propArray[pIdx];
                        break;
                    case 2:
                        s.prop3 = propArray[pIdx];
                        break;
                    case 3:
                        s.prop4 = propArray[pIdx];
                        break;
                    case 4:
                        s.prop5 = propArray[pIdx];
                        break;
                    case 5:
                        s.prop6 = propArray[pIdx];
                        break;
                    case 6:
                        s.prop7 = propArray[pIdx];
                        break;
                    case 7:
                        s.prop8 = propArray[pIdx];
                        break;
                    case 8:
                        s.prop9 = propArray[pIdx];
                        break;
                    default :
                        break;
                }
            }
        }
        //prop code not found do not need to be an exception
        //void (s.t());
        var s_code = s.t();
        if (s_code) {
            document.write(s_code);
        }
        else {
            //error-calling omniture library 
            //TODO: proper error handling 
        }
    }
    else {
        //error-pageName not found.       
        //TODO: proper error handling 
    }
}

function simpleTestCallOne(pageName, props) {
    alert("testOnly function: pageName=" + pageName);
}