select (select sum(bytes)/ power(2, 30) from dba_data_files f)-(select sum(bytes)/ power(2, 30) from dba_free_space f) from dual   

