

create table ebasaran.Top_sql_19092012 as 
select * from (
select a.sql_id, 
       (sum(a.ELAPSED_TIME_DELTA))/decode((sum(a.EXECUTIONS_DELTA)),0,1,sum(a.EXECUTIONS_DELTA))/1000000 elapsed_time_per_exec,
       sum(a.EXECUTIONS_DELTA) executions,
       (sum(a.ELAPSED_TIME_DELTA))/1000000 total_elapsed_time
from DBA_HIST_SQLSTAT a,dba_hist_snapshot b
where a.SNAP_ID=b.snap_id 
and B.BEGIN_INTERVAL_TIME > to_date('17-09-2012 08:55','dd-mm-yyyy hh24:mi') and B.END_INTERVAL_TIME < to_date('17-09-2012 18:05','dd-mm-yyyy hh24:mi')
 and a.instance_number=b.instance_number
group by  a.sql_id) where
elapsed_time_per_exec>1
order by total_elapsed_time desc;


insert into ebasaran.Top_sql_19092012
select * from (
select a.sql_id, 
       (sum(a.ELAPSED_TIME_DELTA))/decode((sum(a.EXECUTIONS_DELTA)),0,1,sum(a.EXECUTIONS_DELTA))/1000000 elapsed_time_per_exec,
       sum(a.EXECUTIONS_DELTA) executions,
       (sum(a.ELAPSED_TIME_DELTA))/1000000 total_elapsed_time
from DBA_HIST_SQLSTAT a,dba_hist_snapshot b
where a.SNAP_ID=b.snap_id 
and B.BEGIN_INTERVAL_TIME > to_date('18-09-2012 08:55','dd-mm-yyyy hh24:mi') and B.END_INTERVAL_TIME < to_date('18-09-2012 18:05','dd-mm-yyyy hh24:mi')
 and a.instance_number=b.instance_number
group by  a.sql_id) where
elapsed_time_per_exec>1
order by total_elapsed_time desc;

commit;




insert into ebasaran.Top_sql_19092012
select * from (
select a.sql_id, 
       (sum(a.ELAPSED_TIME_DELTA))/decode((sum(a.EXECUTIONS_DELTA)),0,1,sum(a.EXECUTIONS_DELTA))/1000000 elapsed_time_per_exec,
       sum(a.EXECUTIONS_DELTA) executions,
       (sum(a.ELAPSED_TIME_DELTA))/1000000 total_elapsed_time
from DBA_HIST_SQLSTAT a,dba_hist_snapshot b
where a.SNAP_ID=b.snap_id 
and B.BEGIN_INTERVAL_TIME > to_date('19-09-2012 08:55','dd-mm-yyyy hh24:mi') and B.END_INTERVAL_TIME < to_date('19-09-2012 18:05','dd-mm-yyyy hh24:mi')
 and a.instance_number=b.instance_number
group by  a.sql_id) where
elapsed_time_per_exec>1
order by total_elapsed_time desc;

commit;

insert into ebasaran.Top_sql_19092012
select * from (
select a.sql_id, 
       (sum(a.ELAPSED_TIME_DELTA))/decode((sum(a.EXECUTIONS_DELTA)),0,1,sum(a.EXECUTIONS_DELTA))/1000000 elapsed_time_per_exec,
       sum(a.EXECUTIONS_DELTA) executions,
       (sum(a.ELAPSED_TIME_DELTA))/1000000 total_elapsed_time
from DBA_HIST_SQLSTAT a,dba_hist_snapshot b
where a.SNAP_ID=b.snap_id 
and B.BEGIN_INTERVAL_TIME >  to_date('03-09-2012 08:55','dd-mm-yyyy hh24:mi') and B.END_INTERVAL_TIME < to_date('03-09-2012 18:05','dd-mm-yyyy hh24:mi')
 and a.instance_number=b.instance_number
 --and a.instance_number=1
group by  a.sql_id) where
elapsed_time_per_exec>1
--and executions>10
order by total_elapsed_time desc;


commit;

drop table ebasaran.Top_sql_19092012_final


create table ebasaran.Top_sql_19092012_final as
select a.sql_id, sum(a.TOTAL_ELAPSED_TIME) TOTAL_ELAPSED_TIME from ebasaran.Top_sql_19092012 a 
group by sql_id
having count(*)> 3  -- Gun say�s�na g�re de�i�ir
order by 2 desc;

drop table ebasaran.topsql_sta_19092012

create table ebasaran.topsql_sta_19092012 as
select f.TOTAL_ELAPSED_TIME,PARSING_SCHEMA_NAME,f.sql_id,trunc(elapsed_time/decode(executions, 0, 1, executions)/1000000) elapsed_time_per_exec, plan_hash_value,hash_value, child_number, first_load_time,
      last_load_time, executions, buffer_gets, trunc(buffer_gets/decode(executions, 0, 1, executions)) gets_per_exec, trunc(rows_processed/decode(executions, 0, 1,
      executions)) rows_return_per_exec
from v$sql s,ebasaran.Top_sql_19092012_final f where s.sql_id=f.sql_id and PARSING_SCHEMA_NAME in ('WEBAUTH','SADMIN') and trunc(elapsed_time/decode(executions, 0, 1, executions)/1000000)>1
order by  f.TOTAL_ELAPSED_TIME desc;

-- Di�er node'a ba�lan�p �al��t�r
insert into ebasaran.topsql_sta_19092012 
select f.TOTAL_ELAPSED_TIME,PARSING_SCHEMA_NAME,f.sql_id,trunc(elapsed_time/decode(executions, 0, 1, executions)/1000000) elapsed_time_per_exec, plan_hash_value,hash_value, child_number, first_load_time,
      last_load_time, executions, buffer_gets, trunc(buffer_gets/decode(executions, 0, 1, executions)) gets_per_exec, trunc(rows_processed/decode(executions, 0, 1,
      executions)) rows_return_per_exec
from v$sql s,ebasaran.Top_sql_19092012_final f where s.sql_id=f.sql_id and PARSING_SCHEMA_NAME in ('WEBAUTH','SADMIN')
 and trunc(elapsed_time/decode(executions, 0, 1, executions)/1000000)>1
 and s.sql_id not in (select sql_id from ebasaran.topsql_sta_19092012)
order by  f.TOTAL_ELAPSED_TIME desc;

--RAPOR 1 -> SQL �STAT�ST�KLER�

SELECT  T.PARSING_SCHEMA_NAME, T.SQL_ID, 
   T.ELAPSED_TIME_PER_EXEC, T.PLAN_HASH_VALUE, T.HASH_VALUE, 
   T.CHILD_NUMBER, T.FIRST_LOAD_TIME, T.LAST_LOAD_TIME, 
   T.EXECUTIONS, T.BUFFER_GETS, T.GETS_PER_EXEC, 
   T.ROWS_RETURN_PER_EXEC
FROM EBASARAN.TOPSQL_STA_19092012 T
order by TOTAL_ELAPSED_TIME desc

drop table ebasaran.topsql_text_19092012

create table ebasaran.topsql_text_19092012 as
select f.sql_id,sql_fulltext, f.TOTAL_ELAPSED_TIME 
from v$sql s, EBASARAN.TOPSQL_STA_19092012 f where s.sql_id=f.sql_id 
order by  f.TOTAL_ELAPSED_TIME desc




DELETE FROM ebasaran.topsql_text_19092012  A WHERE ROWID > (
SELECT min(rowid) FROM ebasaran.topsql_text_19092012 B
WHERE A.sql_id = B.sql_id);

commit;




--RAPOR 1 -> SQL TEXTLER�

SELECT 
T.SQL_ID, T.SQL_FULLTEXT
FROM EBASARAN.TOPSQL_TEXT_19092012 T
order by T.TOTAL_ELAPSED_TIME desc



