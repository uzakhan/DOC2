--undo usage
select sq.sql_text sql_text, t.USED_UREC Records, t.USED_UBLK Blocks, (t.USED_UBLK*8192/1024/1024) USED_UNDO_MB from v$transaction t,
v$session s,
v$sql sq
where t.addr = s.taddr
and s.sql_id = sq.sql_id
--and s.username = 'ARSIV_CRM'

--available undo
SELECT   undo_size/ (SELECT SUM (bytes)
            FROM dba_data_files
           WHERE tablespace_name LIKE 'UNDO%')* 100AS persentage
  FROM (SELECT (SUM (BYTES)) undo_size
          FROM dba_undo_extents
         WHERE TABLESPACE_NAME LIKE 'UNDO%' AND Status != 'EXPIRED');


SELECT a.sid, b.name, a.value
FROM v$sesstat a, v$statname b
WHERE a.statistic# = b.statistic#
and name like  '%undo%'
--AND a.statistic# = 176    -- Which stands for undo change vector size
ORDER BY a.value DESC;


SELECT s.username, s.SID, s.serial#, s.logon_time, t.xidusn, t.ubafil,
t.ubablk, t.used_ublk, t.start_date, t.status
FROM v$session s, v$transaction t
WHERE s.saddr = t.ses_addr
order by t.ubablk DESC;

select sess.USERNAME, tr.XIDUSN "Undo segment number",tr.USED_UBLK "Number of undo blocks used",
tr.USED_UREC " Number of undo records used" from v$transaction tr,v$session sess
where tr.ADDR = sess.TADDR

select status,
  round(sum_bytes / (1024*1024), 0) as MB,
  round((sum_bytes / undo_size) * 100, 0) as PERC
from
(
  select status, sum(bytes) sum_bytes
  from dba_undo_extents
  group by status
),
(
  select sum(a.bytes) undo_size
  from dba_tablespaces c
    join v$tablespace b on b.name = c.tablespace_name
    join v$datafile a on a.ts# = b.ts#
  where c.contents = 'UNDO'
    and c.status = 'ONLINE'
);

select * from V$FAST_START_TRANSACTIONS where state='RECOVERING'



  SELECT a.sid,
         a.username,
         b.used_urec,
         b.used_ublk
    FROM v$session a, v$transaction b
   WHERE a.saddr = b.ses_addr
ORDER BY b.used_ublk DESC;

SELECT a.sid, b.name, a.value
FROM v$sesstat a, v$statname b
WHERE a.statistic# = b.statistic#
AND a.statistic# = 176    --<-- Which stands for undo change vector size
ORDER BY a.value DESC

/* Formatted on 21.02.2013 10:05:39 (QP5 v5.215.12089.38647) */
SELECT sess.username,
       sess.sid,
       sess.serial# serial,
       p.spid "System PID",
       sess.program,
       sess.osuser,
       sess.machine,
       t.used_ublk "Undo blocks",
       t.status "Trans. Status",
       TO_CHAR (logon_time, 'MM/DD/YYYY HH24:MI') "Logged In"
  FROM v$session sess, v$transaction t, v$process p
 WHERE sess.saddr = t.ses_addr AND sess.paddr = p.addr ORDER BY t.status,t.used_ublk desc;
 

  SELECT S.sid || ',' || S.serial# sid_serial,
         S.username,
         S.osuser,
         P.spid,
         S.module,
         P.program,
         SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used,
         T.tablespace,
         COUNT (*) statements
    FROM v$sort_usage T,
         v$session S,
         dba_tablespaces TBS,
         v$process P
   WHERE     T.session_addr = S.saddr
         AND S.paddr = P.addr
         AND T.tablespace = TBS.tablespace_name
GROUP BY S.sid,
         S.serial#,
         S.username,
         S.osuser,
         P.spid,
         S.module,
         P.program,
         TBS.block_size,
         T.tablespace
ORDER BY mb_used;



  SELECT gvs.inst_id "Instance",
         gvs.SID,
         glo.os_user_name "OS User",
         glo.oracle_username "DB User",
         dbo.owner "Schema",
         SUBSTR (dbo.object_name, 1, 30) "Object Name",
         SUBSTR (dbo.object_type, 1, 10) "Object Type",
         SUBSTR (drs.segment_name, 1, 15) "RBS Name",
         gvt.used_urec "# of Records",
         gvt.used_ublk "# of Blocks",
         drs.tablespace_name "Tablespace"
    FROM gv$locked_object glo,
         dba_objects dbo,
         dba_rollback_segs drs,
         gv$transaction gvt,
         gv$session gvs
   WHERE     glo.object_id = dbo.object_id
         AND glo.xidusn = drs.segment_id
         AND glo.xidusn = gvt.xidusn
         AND glo.xidslot = gvt.xidslot
         AND gvt.addr = gvs.taddr
         AND gvt.used_ublk > 1000
ORDER BY gvt.used_ublk DESC;


SELECT  t.used_ublk UBLK,t.used_urec UREC
FROM V$TRANSACTION t, V$SESSION s 
WHERE t.addr = s.taddr;


SELECT TO_CHAR (s.sid) || ',' || TO_CHAR (s.serial#) sid_serial,
       NVL (s.username, 'None') orauser,
       s.program,
       r.name undoseg,
       t.used_ublk * TO_NUMBER (x.VALUE) / 1024 || 'K' "Undo"
  FROM sys.v_$rollname r,
       sys.v_$session s,
       sys.v_$transaction t,
       sys.v_$parameter x
 WHERE s.taddr = t.addr AND r.usn = t.xidusn(+) AND x.name = 'db_block_size';
 
 
SELECT sess.username,
       sess.sid,
       sess.serial# serial,
       p.spid "System PID",
       sess.program,
       sess.osuser,
       sess.machine,
       t.used_ublk "Undo blocks",
       t.status "Trans. Status",
       TO_CHAR (logon_time, 'MM/DD/YYYY HH24:MI') "Logged In"
  FROM v$session sess, v$transaction t, v$process p
 WHERE sess.saddr = t.ses_addr AND sess.paddr = p.addr ORDER
 BY t.status,t.used_ublk desc;
 
 
 select to_char(begin_time,'hh24:mi dd-mon-yyyy') "START",
       to_char(end_time,'hh24:mi dd-mon-yyyy') "END",
       unxpstealcnt,
       expstealcnt,
       activeblks,
       unexpiredblks,
       expiredblks,
       tuned_undoretention
from v$undostat
order by end_time;



select to_char(begin_time,'hh24:mi dd-mon-yyyy') "START",
       to_char(end_time,'hh24:mi dd-mon-yyyy') "END",
       undoblks,
       expblkreucnt,
       ssolderrcnt,
       nospaceerrcnt,
       activeblks,
       unexpiredblks,
       expiredblks,
       tuned_undoretention
from v$undostat
order by end_time;


select s.sid
      ,s.serial#
      ,s.username
      ,s.machine
      ,s.status
      ,s.lockwait
      ,t.used_ublk
      ,t.used_urec
      ,t.start_time
      ,s.sql_id
from gv$transaction t
inner join gv$session s on t.addr = s.taddr;