select * from v$sql s where upper(S.SQL_TEXT) Like 'UPDATE%SET%TTO_POLL_FLAG%ISEMRI%';  


select * from sys.wrh$_active_session_history where user_id=97

select s.sql_id,s.sql_text from sys.wrh$_active_session_history  w ,v$sqlarea s  where user_id=97 and w.sql_id=s.sql_id(+)

  



select * from v$sql s where sql_id='bunvx480ynf57'