select /*+ PARALLEL (a,7)*/ count(1) 
from  tms.user_exception a 
where A.OLUSMA_ZAMANI BETWEEN TO_DATE('18102010','DDMMYYYY') AND TO_DATE('23102010','DDMMYYYY')

select /*+ PARALLEL (a,7)*/ count(1) 
from  tms.user_exception a 
where A.OLUSMA_ZAMANI BETWEEN TO_DATE('18102010','DDMMYYYY') AND TO_DATE('23102010','DDMMYYYY')
    