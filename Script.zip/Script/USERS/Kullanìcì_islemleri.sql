
---*-*-*-*TMS schemasina select hakki verme *-*-*-*-*-*-*

CREATE USER ecinar IDENTIFIED BY "ec594_" profile select_profile password expire;

GRANT connect TO ecinar;
grant resource TO ecinar;
grant tttms to ecinar;
ALTER USER ecinar DEFAULT ROLE ALL;
revoke unlimited tablespace from ecinar;
ALTER USER ecinar QUOTA 100M ON USERS;
--grant resource to hrkaraca;


CREATE USER DALAGOZ
  IDENTIFIED BY "dg301_"
  DEFAULT TABLESPACE USERS
  TEMPORARY TABLESPACE TEMP_TEMP
  PROFILE SELECT_PROFILE
  PASSWORD EXPIRE
  ACCOUNT UNLOCK;
  -- 4 Roles for DALAGOZ 
  GRANT TTTMS TO DALAGOZ;
  GRANT CONNECT TO DALAGOZ;
  GRANT RESOURCE TO DALAGOZ;
  GRANT SELECT_TT_ADRES TO DALAGOZ;
  ALTER USER DALAGOZ DEFAULT ROLE ALL;
  -- 1 Tablespace Quota for DALAGOZ 
  ALTER USER DALAGOZ QUOTA 100M ON USERS;
  revoke unlimited tablespace from DALAGOZ;
  





select 'grant select on ' || owner || '.' || table_name || ' to hrkaraca;' from dba_tables t where t.owner in ('TMS')

union all

select 'grant select on ' || owner || '.' || view_name || ' to hrkaraca;' from dba_views t where t.owner in ('TMS')


-- select Role'e eksik yetkiler verme

SELECT 'GRANT SELECT ON '||OWNER||'.'||TABLE_NAME||' TO SELECT_TT_R1;'
FROM (
SELECT T.OWNER, TABLE_NAME FROM DBA_TABLES T where T.OWNER='TT_R1'
MINUS
select T.owner, TABLE_NAME from dba_tab_privs t where t.grantee = 'SELECT_TT_R1')





