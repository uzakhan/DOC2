document.write('<su:badge layout="1"  location="http://www.kamilturkyilmaz.com/2012/01/31/oracle-veritabani-denetim/"></su:badge>');
document.write(" \
<script type=\"text/javascript\"> \
  (function() { \
    var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true; \
    li.src = window.location.protocol + '//platform.stumbleupon.com/1/widgets.js'; \
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s); \
  })(); \
</script>");


