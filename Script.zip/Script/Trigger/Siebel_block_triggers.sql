CREATE OR REPLACE TRIGGER SIEBEL.BLOCK_INSERT_UPDATE_TRIG
   BEFORE INSERT OR UPDATE
   ON siebel.S_ORG_EXT
   FOR EACH ROW
BEGIN
   IF INSERTING
   THEN
      IF :NEW.CREATED_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri olusturulmasina izin verilmiyor.');
      END IF;
   ELSIF UPDATING THEN
     IF :NEW.LAST_UPD_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri guncellemesine izin verilmiyor.');
      END IF;
   END IF;
END;
/


CREATE OR REPLACE TRIGGER SIEBEL.CONTACT_BLOCK_INS_UPD_TRIG
before insert or update
on SIEBEL.S_CONTACT 
for each row
begin
      IF INSERTING
   THEN
      IF :NEW.CREATED_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri olusturulmasina izin verilmiyor.');
      END IF;
   ELSIF UPDATING THEN
     IF :NEW.LAST_UPD_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri guncellemesine izin verilmiyor.');
      END IF;
   END IF;
end;
/


CREATE OR REPLACE TRIGGER SIEBEL.DOCAGREE_BLOCK_INS_UPD_TRIG
   BEFORE INSERT OR UPDATE
   ON SIEBEL.S_DOC_AGREE
   FOR EACH ROW
BEGIN
   IF INSERTING
   THEN
      IF :NEW.CREATED_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri olusturulmasina izin verilmiyor.');
      END IF;
   ELSIF UPDATING
   THEN
      IF :NEW.LAST_UPD_BY <> '1-2DPJ-145'
      THEN
         raise_application_error (
            -20933,
            'Gecici olarak musteri guncellemesine izin verilmiyor.');
      END IF;
   END IF;
END;
/
