create  or replace  trigger ebasaran.block_insert_update_trig
before insert or update
on ebasaran.deneme2 
for each row
begin
        raise_application_error( -20933, 'Gecici olarak musteri guncellemesine izin verilmiyor.');
end; 


drop trigger siebel.contact_block_ins_upd_trig

create  or replace  trigger siebel.contact_block_ins_upd_trig
before insert or update
on SIEBEL.S_CONTACT 
for each row
begin
        raise_application_error( -20933, 'Gecici olarak musteri guncellemesine izin verilmiyor.');
end; 