create or replace trigger logon_trig
after logon on PP4_SOAINFRA.schema
declare
   c1  integer;
   r1 integer;
BEGIN
   execute immediate 'alter session set max_dump_file_size=UNLIMITED';
   execute immediate 'ALTER SESSION SET TRACEFILE_IDENTIFIER =@';
   execute immediate 'alter session set events ''10046 trace name context forever, level 12'''; END; /
