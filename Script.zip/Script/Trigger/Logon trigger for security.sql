CREATE TABLE OPERASYON.LOGON_HISTORY
(
  TARIH     DATE,
  INSTANCE  VARCHAR2(50 BYTE),
  TERMINAL  VARCHAR2(50 BYTE),
  HOST      VARCHAR2(50 BYTE),
  OS_USER   VARCHAR2(50 BYTE),
  DB_USER   VARCHAR2(50 BYTE),
  IP        VARCHAR2(50 BYTE),
  PROGRAM   VARCHAR2(50 BYTE)
);
/

grant select on OPERASYON.logon_history to FMS_ZIRA;
grant insert on OPERASYON.logon_history to FMS_ZIRA;

grant select on sys.gv_$mystat to FMS_ZIRA;

grant select on sys.gv_$session to FMS_ZIRA;

grant select on sys.gv_$session to FMS_ZIRA;

grant select on sys.gv_$instance   to FMS_ZIRA;
grant select on sys.v_$instance   to FMS_ZIRA;




CREATE OR REPLACE TRIGGER FMS_ZIRA.LOGON_FMS_TRG
   AFTER LOGON
   ON FMS_ZIRA.SCHEMA
DECLARE
   rLogon   OPERASYON.logon_history%ROWTYPE;
BEGIN
   SELECT program
     INTO rLogon.Program
     FROM v$session v
    WHERE v.sid = (SELECT sid
                     FROM gv$mystat
                    WHERE ROWNUM = 1);

   SELECT host_name INTO rLogon.Instance FROM v$instance;

   SELECT SYS_CONTEXT  ('USERENV', 'TERMINAL'),
          SYS_CONTEXT  ('USERENV', 'SESSION_USER'),
          SYS_CONTEXT  ('USERENV', 'HOST'),
          SYS_CONTEXT  ('USERENV', 'OS_USER'),
          SYS_CONTEXT  ('USERENV', 'IP_ADDRESS')
     INTO rLogon.Terminal,
          rLogon.Db_User,
          rLogon.HOST,
          rLogon.Os_User,
          rLogon.Ip
     FROM DUAL;

   INSERT INTO OPERASYON.logon_history (tarih,
                                  instance,
                                  terminal,
                                  HOST,
                                  os_user,
                                  db_user,
                                  ip,
                                  program)
        VALUES (SYSDATE,
                rLogon.instance,
                rLogon.terminal,
                rLogon.HOST,
                rLogon.os_user,
                rLogon.db_user,
                rLogon.ip,
                rLogon.program);
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
/
