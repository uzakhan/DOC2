PDRTJS_5873059_post_379.avg_rating = 0;
PDRTJS_5873059_post_379.votes = 0;		
PDRTJS_settings_5873059_post_379= {"type" : "stars","size" : "sml","star_color" : "yellow","custom_star" : "","font_size" : "","font_line_height" : "16px","font_color" : "","font_align" : "left","font_position" : "right","font_family" : "","font_bold" : "normal","font_italic" : "normal","text_vote" : "Vote","text_votes" : "Votes","text_rate_this" : "Rate This","text_1_star" : "Very Poor","text_2_star" : "Poor","text_3_star" : "Average","text_4_star" : "Good","text_5_star" : "Excellent","text_thank_you" : "Thank You","text_rate_up" : "Rate Up","text_rate_down" : "Rate Down"};
PDRTJS_5873059_post_379.init();		
PDRTJS_5873059_post_379.token='e29e38d4530e87debf7a89e52b49b30f';
/*5873059,_post_379,wp-post-379,3566993514,0-0*/