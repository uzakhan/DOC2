PDRTJS_5873059_post_381.avg_rating = 0;
PDRTJS_5873059_post_381.votes = 0;		
PDRTJS_settings_5873059_post_381= {"type" : "stars","size" : "sml","star_color" : "yellow","custom_star" : "","font_size" : "","font_line_height" : "16px","font_color" : "","font_align" : "left","font_position" : "right","font_family" : "","font_bold" : "normal","font_italic" : "normal","text_vote" : "Vote","text_votes" : "Votes","text_rate_this" : "Rate This","text_1_star" : "Very Poor","text_2_star" : "Poor","text_3_star" : "Average","text_4_star" : "Good","text_5_star" : "Excellent","text_thank_you" : "Thank You","text_rate_up" : "Rate Up","text_rate_down" : "Rate Down"};
PDRTJS_5873059_post_381.init();		
PDRTJS_5873059_post_381.token='d5d3277e96c79549bd42555df80444bd';
/*5873059,_post_381,wp-post-381,3566993514,0-0*/