--- Bu �al��ma s�ras�nda a�a��daki sorgular kullan�ld�:

select to_char(begin_time, 'DD-MM HH24:MI') , maxqueryid, maxquerylen, tuned_undoretention from v$undostat order by begin_time;

TO_CHAR(BEG MAXQUERYID      MAXQUERYLEN TUNED_UNDORETENTION
----------- ------------- ----------- ------------------- ...
20-10 09:19 05snzaujvs8az      277565            88719
20-10 09:29 05snzaujvs8az      278172            88631
20-10 09:39 05snzaujvs8az      278778            88656
20-10 09:49 05snzaujvs8az      279385            88651
20-10 09:59 05snzaujvs8az      279992            88637
20-10 10:09 05snzaujvs8az      280600            88621
20-10 10:19 05snzaujvs8az      281207            88676
20-10 10:29 05snzaujvs8az      281510            88723
20-10 10:39 05snzaujvs8az      282117            88760
20-10 10:49 05snzaujvs8az      282725            88856
20-10 10:59 05snzaujvs8az      283332            88923

##############################################################################################

select sid, user_name from v$open_cursor where sql_id='05snzaujvs8az';

       SID USER_NAME
---------- ------------------------------
      1573 TAS
      1587 TAS


##############################################################################################

select username, program, background from v$process where addr in ( select paddr from v$session where sid in ( 1573, 1587 ) );

USERNAME    PROGRAM                      B
--------------- ------------------------------------------------ -
oracle        oracle@dicle (J006)
oracle        oracle@dicle (J003)

##############################################################################################

Errorstack al�nd���nda her iki jobun da VIP prosed�r�n� �al��t�rd��� belirlendi.

/oracle/admin/TMS/bdump/tms2_j003_25451.trc
Oracle Database 10g Enterprise Edition Release 10.1.0.4.0 - 64bit Production With the Partitioning, Real Application Clusters, OLAP and Data Mining options ORACLE_HOME = /oracle/product/10.1.0
System name:    HP-UX
Node name:    dicle
Release:    B.11.11
Version:    U
Machine:    9000/800
Instance name: TMS2
Redo thread mounted by this instance: 2
Oracle process number: 66
Unix process pid: 25451, image: oracle@dicle (J003)

*** SERVICE NAME:(SYS$USERS) 2010-10-20 10:55:25.014
*** SESSION ID:(1587.2) 2010-10-20 10:55:25.014
*** 2010-10-20 10:55:25.014
ksedmp: internal or fatal error
Current SQL statement for this session:
DECLARE job BINARY_INTEGER := :job; next_date DATE := :mydate;    broken BOOLEAN := FALSE; 
BEGIN vip(234,234); :mydate := next_date; IF broken THEN :b := 1; ELSE :
b := 0; END IF; END;
----- PL/SQL Call Stack -----
  object      line  object
  handle    number  name
c0000003aeaacc18    45  procedure TAS.VIP
c0000003afd560e0     1  anonymous block
